# Data

Place your dataset here.

For a larger dataset, download **Sentiment140** from Kaggle:
https://www.kaggle.com/datasets/kazanova/sentiment140

It contains 1.6 million labeled tweets which will give much better model accuracy.

To use it, update the data loading section in `src/sentiment_analysis.py`:

```python
df = pd.read_csv('data/training.1600000.processed.noemoticon.csv',
                 encoding='latin-1',
                 names=['target', 'id', 'date', 'flag', 'user', 'text'])

df['sentiment'] = df['target'].map({0: 'negative', 2: 'neutral', 4: 'positive'})
df['cleaned'] = df['text'].apply(clean_text)
```
