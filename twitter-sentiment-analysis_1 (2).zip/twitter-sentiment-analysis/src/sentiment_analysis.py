# sentiment analysis on twitter data
# i collected some tweets manually and also used a small dataset i found online
# tried two models - naive bayes and logistic regression, NB worked better for me
# reference: krish naik youtube + sklearn docs

import re
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import joblib
import warnings

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix

warnings.filterwarnings('ignore')


# i manually labeled these tweets to create a small training dataset
# planning to use sentiment140 later for better accuracy

tweets_data = [
    # positive tweets
    ("I absolutely love this new phone best purchase ever", "positive"),
    ("What a beautiful day feeling so grateful and happy", "positive"),
    ("just got promoted so excited about this opportunity", "positive"),
    ("the food here was amazing highly recommend this place", "positive"),
    ("cant believe how supportive my friends are love them so much", "positive"),
    ("this movie was fantastic 10 out of 10 would watch again", "positive"),
    ("woke up feeling great today lets go", "positive"),
    ("my team won the match what an incredible game", "positive"),
    ("finally done with my project so proud of myself", "positive"),
    ("the sunset today was so beautiful nature is amazing", "positive"),
    ("got an A in my exam all the hardwork paid off", "positive"),
    ("best birthday surprise ever my friends are the best", "positive"),
    ("this book completely changed how i think highly recommend", "positive"),
    ("coding is honestly so fun when things work", "positive"),
    ("just got a puppy my heart is so full", "positive"),
    ("feeling really motivated today going to have a great day", "positive"),
    ("my family surprised me today feeling so loved", "positive"),
    ("passed my driving test on first attempt so happy", "positive"),

    # negative tweets
    ("this is the worst service i have ever seen absolutely disgusting", "negative"),
    ("i hate mondays everything went wrong today", "negative"),
    ("the app keeps crashing so frustrated right now", "negative"),
    ("lost my wallet and missed my flight terrible terrible day", "negative"),
    ("why does everything always go wrong so tired of this", "negative"),
    ("customer support was completely useless never buying from here again", "negative"),
    ("stuck in traffic for 2 hours going to be late again", "negative"),
    ("this laptop is garbage broke after just one week", "negative"),
    ("cant believe how rude people can be so disappointed", "negative"),
    ("failed my exam after studying so hard heartbroken", "negative"),
    ("weather has been miserable all week im done", "negative"),
    ("terrible movie total waste of my time", "negative"),
    ("order arrived completely damaged this is unacceptable", "negative"),
    ("so stressed out nothing is going right lately", "negative"),
    ("got laid off today dont know what to do now", "negative"),
    ("headache since morning and nothing is working out", "negative"),
    ("missed the deadline now my boss is angry at me", "negative"),
    ("phone screen cracked on the very first day so upset", "negative"),

    # neutral tweets
    ("just woke up going to make some coffee", "neutral"),
    ("meeting is at 3pm tomorrow", "neutral"),
    ("it rained today in pune", "neutral"),
    ("went to the store and bought some vegetables", "neutral"),
    ("report submission is on friday", "neutral"),
    ("currently reading a book on machine learning", "neutral"),
    ("train arrives at 9 45 am", "neutral"),
    ("had rice and dal for lunch", "neutral"),
    ("new software update is available now", "neutral"),
    ("attended a seminar on data science today", "neutral"),
    ("office will remain closed on monday", "neutral"),
    ("flight is at 6 in the morning", "neutral"),
    ("just watched the news", "neutral"),
    ("package will be delivered by thursday", "neutral"),
    ("dentist appointment is tomorrow morning", "neutral"),
    ("going to the library after college", "neutral"),
    ("class starts at 10 am", "neutral"),
    ("downloaded the new app to check it out", "neutral"),
]


# basic text cleaning function
# learned about regex from geeksforgeeks and applied here
def clean_text(tweet):
    tweet = tweet.lower()
    tweet = re.sub(r'http\S+', '', tweet)       # removing links
    tweet = re.sub(r'@\w+', '', tweet)           # removing mentions
    tweet = re.sub(r'#', '', tweet)              # remove hashtag symbol but keep word
    tweet = re.sub(r'[^a-zA-Z\s]', '', tweet)   # remove special chars and numbers
    tweet = re.sub(r'\s+', ' ', tweet).strip()
    return tweet


# loading data into dataframe
df = pd.DataFrame(tweets_data, columns=['tweet', 'sentiment'])
df['cleaned'] = df['tweet'].apply(clean_text)

print("Dataset shape:", df.shape)
print("\nLabel distribution:")
print(df['sentiment'].value_counts())
print()


# splitting dataset - 75% train 25% test
X = df['cleaned']
y = df['sentiment']

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

print(f"Training samples: {len(X_train)}")
print(f"Testing samples: {len(X_test)}\n")


# tfidf converts text to numbers that the model can understand
# ngram_range=(1,2) means it considers both single words and word pairs
tfidf = TfidfVectorizer(max_features=3000, ngram_range=(1, 2))
X_train_vec = tfidf.fit_transform(X_train)
X_test_vec = tfidf.transform(X_test)


# training naive bayes model
# multinomial NB works well with text data, learned this from sklearn docs
nb_model = MultinomialNB()
nb_model.fit(X_train_vec, y_train)
nb_pred = nb_model.predict(X_test_vec)
nb_acc = accuracy_score(y_test, nb_pred)

print("--- Naive Bayes Results ---")
print(f"Accuracy: {nb_acc * 100:.2f}%")
print(classification_report(y_test, nb_pred))


# also trying logistic regression to compare
lr_model = LogisticRegression(max_iter=500, random_state=42)
lr_model.fit(X_train_vec, y_train)
lr_pred = lr_model.predict(X_test_vec)
lr_acc = accuracy_score(y_test, lr_pred)

print("--- Logistic Regression Results ---")
print(f"Accuracy: {lr_acc * 100:.2f}%")
print(classification_report(y_test, lr_pred))


# saving the better model
if nb_acc >= lr_acc:
    best_model = nb_model
    best_name = "Naive Bayes"
else:
    best_model = lr_model
    best_name = "Logistic Regression"

print(f"\nBetter model: {best_name} with {max(nb_acc, lr_acc)*100:.2f}% accuracy")

# saving tfidf and model separately so i can load them later
joblib.dump(best_model, 'results/model.pkl')
joblib.dump(tfidf, 'results/tfidf.pkl')
print("Model and vectorizer saved.")


# --- plots ---

fig, axes = plt.subplots(1, 3, figsize=(16, 5))
fig.suptitle('Twitter Sentiment Analysis - Results', fontsize=14)

# plot 1: how many tweets of each type in dataset
counts = df['sentiment'].value_counts()
colors = ['#4CAF50', '#F44336', '#2196F3']
axes[0].bar(counts.index, counts.values, color=colors, edgecolor='black', linewidth=0.8)
axes[0].set_title('Tweet Count by Sentiment')
axes[0].set_xlabel('Sentiment')
axes[0].set_ylabel('Count')
for i, v in enumerate(counts.values):
    axes[0].text(i, v + 0.3, str(v), ha='center', fontsize=11)

# plot 2: model accuracy comparison
model_names = ['Naive Bayes', 'Logistic Regression']
accuracies = [nb_acc, lr_acc]
bar_colors = ['#4CAF50' if a == max(accuracies) else '#90A4AE' for a in accuracies]
axes[1].bar(model_names, accuracies, color=bar_colors, edgecolor='black', linewidth=0.8)
axes[1].set_title('Model Accuracy Comparison')
axes[1].set_xlabel('Model')
axes[1].set_ylabel('Accuracy')
axes[1].set_ylim(0, 1.1)
for i, v in enumerate(accuracies):
    axes[1].text(i, v + 0.02, f'{v*100:.1f}%', ha='center', fontsize=11)

# plot 3: confusion matrix of the best model
if best_name == "Naive Bayes":
    best_pred = nb_pred
else:
    best_pred = lr_pred

labels_order = ['negative', 'neutral', 'positive']
cm = confusion_matrix(y_test, best_pred, labels=labels_order)
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=labels_order, yticklabels=labels_order, ax=axes[2])
axes[2].set_title(f'Confusion Matrix ({best_name})')
axes[2].set_xlabel('Predicted')
axes[2].set_ylabel('Actual')

plt.tight_layout()
plt.savefig('results/results.png', dpi=120, bbox_inches='tight')
plt.show()
print("Plot saved as results/results.png")


# testing on some new tweets i wrote myself
print("\n--- Testing on new tweets ---")

new_tweets = [
    "This AI tool is honestly so impressive blew my mind",
    "worst experience ever app is broken and nobody is helping",
    "just read an article about climate change",
    "feeling really happy today life is good",
    "so disappointed with the results expected way better",
    "going to the canteen after this lecture",
]

# need to clean and vectorize before predicting
cleaned_new = [clean_text(t) for t in new_tweets]
new_vec = tfidf.transform(cleaned_new)
predictions = best_model.predict(new_vec)

for tweet, pred in zip(new_tweets, predictions):
    print(f"  [{pred.upper()}] {tweet}")
