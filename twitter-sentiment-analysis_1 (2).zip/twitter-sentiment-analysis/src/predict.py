# use this file to test the model on your own tweets
# make sure you have run sentiment_analysis.py first to generate model.pkl and tfidf.pkl

import re
import joblib

def clean_text(tweet):
    tweet = tweet.lower()
    tweet = re.sub(r'http\S+', '', tweet)
    tweet = re.sub(r'@\w+', '', tweet)
    tweet = re.sub(r'#', '', tweet)
    tweet = re.sub(r'[^a-zA-Z\s]', '', tweet)
    tweet = re.sub(r'\s+', ' ', tweet).strip()
    return tweet

# load saved model and vectorizer
model = joblib.load('results/model.pkl')
tfidf  = joblib.load('results/tfidf.pkl')

# add your own tweets here
my_tweets = [
    "just got my internship offer letter so happy",
    "wifi is not working again so annoying",
    "submitted the assignment before deadline",
    "today was a really good day overall",
    "the food in canteen was bad today",
]

print("Sentiment Predictions")
print("-" * 45)

cleaned = [clean_text(t) for t in my_tweets]
vectors = tfidf.transform(cleaned)
preds   = model.predict(vectors)

for tweet, label in zip(my_tweets, preds):
    tag = label.upper()
    print(f"[{tag:8}]  {tweet}")
