# Twitter Sentiment Analysis 🐦

A machine learning project that classifies tweets as **Positive**, **Negative**, or **Neutral** using NLP techniques.

Built as part of my AI/ML internship project at **Codec Technologies**.

---

## Demo

![Results](results/results.png)

---

## About the Project

I wanted to build something that actually works on real text data, so I chose sentiment analysis on tweets. The idea is simple — given a tweet, can a model figure out whether the person is happy, upset, or just stating a fact?

I tried two different models and compared their performance:
- **Naive Bayes** — works surprisingly well for text, fast to train
- **Logistic Regression** — a bit more flexible, good baseline

TF-IDF was used to convert text into numbers since models can't directly read words.

---

## Project Structure

```
twitter-sentiment-analysis/
│
├── src/
│   ├── sentiment_analysis.py   # main training script
│   └── predict.py              # load model and test your own tweets
│
├── data/                       # place your dataset here
├── results/                    # saved model, vectorizer, plots
├── requirements.txt
└── README.md
```

---

## How to Run

**1. Clone the repository**
```bash
git clone https://github.com/YOUR_USERNAME/twitter-sentiment-analysis.git
cd twitter-sentiment-analysis
```

**2. Install dependencies**
```bash
pip install -r requirements.txt
```

**3. Train the model**
```bash
python src/sentiment_analysis.py
```

**4. Test on your own tweets**

Open `src/predict.py`, add your tweets in the list, then run:
```bash
python src/predict.py
```

---

## How It Works

```
Raw Tweet
   ↓
Text Cleaning  →  lowercase, remove URLs, mentions, punctuation
   ↓
TF-IDF         →  convert words to numerical features (unigrams + bigrams)
   ↓
Model          →  Naive Bayes / Logistic Regression
   ↓
Output         →  Positive / Negative / Neutral
```

---

## Results

| Model | Accuracy |
|---|---|
| Naive Bayes | 64.29% |
| Logistic Regression | 64.29% |

> Note: accuracy will improve a lot with a larger dataset like Sentiment140 (1.6M tweets). This version uses a small manually labeled dataset for demonstration.

---

## Sample Predictions

```
[POSITIVE]  This AI tool is honestly so impressive blew my mind
[NEGATIVE]  worst experience ever app is broken and nobody is helping
[NEUTRAL ]  just read an article about climate change
[POSITIVE]  feeling really happy today life is good
[NEGATIVE]  so disappointed with the results expected way better
[NEUTRAL ]  going to the canteen after this lecture
```

---

## Tech Stack

- Python 3.x
- scikit-learn
- pandas, numpy
- matplotlib, seaborn
- TF-IDF Vectorizer
- Naive Bayes (MultinomialNB)
- Logistic Regression

---

## What I Learned

- How to preprocess raw text data using regex
- How TF-IDF works and why it's useful for text classification
- Difference between Naive Bayes and Logistic Regression for NLP tasks
- How to evaluate a classification model using confusion matrix and F1 score
- End to end ML pipeline: data → train → evaluate → save → predict

---

## Future Improvements

- [ ] Use Sentiment140 dataset (1.6M labeled tweets) for better accuracy
- [ ] Add NLTK stopword removal
- [ ] Try LSTM or BERT for better results
- [ ] Build a simple web interface using Flask

---

## Author

**Sarang**
BTech AI & ML | JSPM University, Pune
School of Computational Sciences — Division G

---

## License

MIT License — free to use and modify.
